'use client';

import { useState } from 'react';

const people = [
  { name: 'Ana', age: 28, city: 'São Paulo', emoji: '👩🏻', text: 'Gosto de música, viagens e boas conversas.' },
  { name: 'Marina', age: 31, city: 'Rio de Janeiro', emoji: '👩🏽', text: 'Procuro alguém para compartilhar momentos.' },
  { name: 'Camila', age: 26, city: 'Belo Horizonte', emoji: '👩🏼', text: 'Café, cinema e música fazem meu dia.' }
];

export default function Home() {
  const [active, setActive] = useState('Encontrar');
  const [liked, setLiked] = useState([]);
  const [showChat, setShowChat] = useState(false);

  function like(name) {
    setLiked(v => v.includes(name) ? v : [...v, name]);
  }

  return (
    <main>
      <header className="topbar">
        <div className="brand"><span className="heart">♥</span> AmorConecta</div>
        <div className="trial">1 dia grátis • R$ 9,99/mês</div>
        <button className="premium">Assinar</button>
      </header>

      <section className="hero">
        <div>
          <span className="tag">💜 Seu novo encontro pode começar aqui</span>
          <h1>Conecte-se com pessoas que combinam com você.</h1>
          <p>Conheça pessoas, converse com segurança e crie conexões reais.</p>
          <div className="actions">
            <button onClick={() => setActive('Encontrar')}>Encontrar pessoas</button>
            <button className="secondary" onClick={() => setActive('Conversas')}>Abrir conversas</button>
          </div>
        </div>
        <div className="heroCard">
          <div className="bigAvatar">💑</div>
          <strong>AmorConecta</strong>
          <span>Chat • Vídeo • Música • Presentes</span>
        </div>
      </section>

      <nav className="tabs">
        {['Encontrar','Conversas','Chamadas','Música','Presentes'].map(x =>
          <button key={x} className={active===x?'active':''} onClick={()=>setActive(x)}>{x}</button>
        )}
      </nav>

      {active === 'Encontrar' && (
        <section className="content">
          <div className="sectionTitle">
            <div><h2>Pessoas perto de você</h2><p>Novos perfis para conhecer</p></div>
            <span className="online">● Online</span>
          </div>
          <div className="grid">
            {people.map(p => (
              <article className="profile" key={p.name}>
                <div className="avatar">{p.emoji}</div>
                <h3>{p.name}, {p.age}</h3>
                <small>📍 {p.city}</small>
                <p>{p.text}</p>
                <div className="cardActions">
                  <button className="like" onClick={()=>like(p.name)}>💜 {liked.includes(p.name)?'Curtido':'Curtir'}</button>
                  <button onClick={()=>setShowChat(true)}>💬 Conversar</button>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {active === 'Conversas' && <Feature title="💬 Conversas" text="Aqui ficará o chat em tempo real no estilo WhatsApp, conectado ao Supabase." />}
      {active === 'Chamadas' && <Feature title="📹 Chamada de vídeo privada" text="Área preparada para integração de chamadas de vídeo e voz." />}
      {active === 'Música' && <Feature title="🎵 Música online" text="Área preparada para reprodução de música respeitando as licenças e direitos autorais." />}
      {active === 'Presentes' && <Feature title="🎁 Presentes e figurinhas" text="Envie presentes virtuais e figurinhas nas conversas." />}

      <footer>
        <strong>AmorConecta</strong>
        <span>Privacidade • Termos • Segurança • Ajuda</span>
      </footer>

      {showChat && <div className="modal" onClick={()=>setShowChat(false)}>
        <div className="chat" onClick={e=>e.stopPropagation()}>
          <div className="chatHead">💬 Nova conversa <button onClick={()=>setShowChat(false)}>×</button></div>
          <div className="messages"><div className="bubble">Olá! 👋 Que bom conhecer você.</div></div>
          <div className="composer"><input placeholder="Digite uma mensagem..." /><button>➤</button></div>
        </div>
      </div>}
    </main>
  );
}

function Feature({title,text}) {
  return <section className="feature"><div className="featureIcon">✨</div><h2>{title}</h2><p>{text}</p><button>Continuar configuração</button></section>
}
