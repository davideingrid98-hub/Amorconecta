import './globals.css';

export const metadata = {
  title: 'AmorConecta',
  description: 'Conecte-se, converse e encontre novas pessoas.'
};

export default function RootLayout({ children }) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
