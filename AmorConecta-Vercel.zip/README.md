# AmorConecta

Projeto inicial publicável no Vercel.

## Recursos visuais incluídos
- Tema escuro
- Página inicial responsiva
- Busca de pessoas
- Curtidas
- Conversa em estilo WhatsApp
- Área de chamadas de vídeo/voz
- Área de música
- Presentes e figurinhas
- Plano: 1 dia grátis e depois R$ 9,99/mês

## Próximas integrações
Para funcionamento real, conecte Supabase, Mercado Pago e um serviço de vídeo/voz. As chaves ficam em variáveis de ambiente e não devem ser colocadas no código.

## Publicação
1. Instale as dependências: npm install
2. Teste: npm run dev
3. Publique no Vercel.
